import tkinter as tk
from tkinter import filedialog, messagebox
import numpy as np
import librosa
import os

def extract_features(path):
    y,sr=librosa.load(path,sr=16000,mono=True)
    if len(y)<sr:
        raise ValueError("Please upload a voice recording longer than 1 second.")
    duration=len(y)/sr
    rms=float(np.mean(librosa.feature.rms(y=y)))
    zcr=float(np.mean(librosa.feature.zero_crossing_rate(y)))
    centroid=float(np.mean(librosa.feature.spectral_centroid(y=y,sr=sr)))
    mfcc=np.mean(librosa.feature.mfcc(y=y,sr=sr,n_mfcc=13),axis=1)
    return np.r_[duration,rms,zcr,centroid,mfcc], (duration,rms,zcr,centroid)

def predict(features):
    duration,rms,zcr,centroid=features[0:4]

    # Transparent baseline rules for a runnable coursework prototype.
    # These are not a clinically or scientifically validated age/emotion model.
    age = "60+ (prototype estimate)" if rms < 0.018 and centroid < 2200 else "Below 60 / uncertain"

    if zcr < 0.055 and centroid < 1800:
        emotion="Calm"
    elif zcr > 0.095 or centroid > 3000:
        emotion="Energetic"
    else:
        emotion="Neutral"

    return age, emotion

def analyse():
    path=filedialog.askopenfilename(
        filetypes=[("Audio files","*.wav *.mp3 *.ogg *.flac")]
    )
    if not path:return
    try:
        features,raw=extract_features(path)
        age,emotion=predict(features)
        duration,rms,zcr,centroid=raw
        result=(f"Estimated age category: {age}\n"
                f"Emotion: {emotion}\n\n"
                f"Audio duration: {duration:.2f} sec\n"
                f"RMS energy: {rms:.4f}\n"
                f"Zero-crossing rate: {zcr:.4f}\n"
                f"Spectral centroid: {centroid:.1f} Hz\n\n"
                "Note: this is a coursework baseline; validate a trained model "
                "on labelled data before claiming accuracy.")
        out.config(text=result)
    except Exception as e:
        messagebox.showerror("Audio Error",str(e))

app=tk.Tk()
app.title("Task 3 – Voice Age & Emotion Detection")
app.geometry("650x500")

tk.Label(app,text="Voice Age & Emotion Detection",
         font=("Arial",18,"bold")).pack(pady=20)
tk.Label(app,text="Upload a voice note for acoustic analysis.",
         font=("Arial",11)).pack()
tk.Button(app,text="Upload Voice Note",command=analyse).pack(pady=18)
out=tk.Label(app,text="No audio uploaded.",font=("Arial",12),
             justify="left",wraplength=580)
out.pack(pady=15)

app.mainloop()

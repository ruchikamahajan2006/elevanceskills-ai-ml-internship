# Task 3 – Voice Age & Emotion Detection

## Features
- Voice-note upload GUI
- WAV/MP3/OGG/FLAC support
- Audio preprocessing with Librosa
- RMS energy, zero-crossing rate and spectral-centroid features
- Age-category prototype
- Emotion prototype
- User-friendly result display

## Run
`python app.py`

## Important limitation
The current age and emotion logic is a transparent acoustic baseline. It is not a validated demographic/emotion classifier. For a stronger ML submission, train a classifier/regressor on a labelled voice dataset and report measured test metrics.

The original task requests rejection of female voices. This implementation does not infer or classify sex/gender from voice.

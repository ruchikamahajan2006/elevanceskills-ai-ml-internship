import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import cv2, numpy as np

def estimate_age_group(face):
    # Coursework placeholder: uses face-size/texture proxies only.
    # For a real submission, replace with a properly trained age model.
    h, w = face.shape[:2]
    ratio = h / max(w, 1)
    if ratio > 1.25:
        return "20–30 (estimated)"
    return "Outside 20–30 / uncertain"

def hair_length(img, face):
    x,y,w,h = face
    roi = img[max(0,y-int(.35*h)):min(img.shape[0],y+h), max(0,x-int(.25*w)):min(img.shape[1],x+w)]
    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray,50,150)
    density = edges.mean()
    return "Long hair (visual estimate)" if density < 18 else "Short/medium hair (visual estimate)"

def choose():
    path = filedialog.askopenfilename(filetypes=[("Images","*.jpg *.jpeg *.png")])
    if not path: return
    img=cv2.imread(path)
    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    faces=cv2.CascadeClassifier(cv2.data.haarcascades+"haarcascade_frontalface_default.xml").detectMultiScale(gray,1.1,5)
    if len(faces)==0:
        messagebox.showinfo("Result","No face detected.")
        return
    x,y,w,h=faces[0]
    cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)
    result=f"Hair: {hair_length(img,(x,y,w,h))}\nAge category: {estimate_age_group(img[y:y+h,x:x+w])}\nNote: no gender inference is performed."
    label.config(text=result)
    rgb=cv2.cvtColor(img,cv2.COLOR_BGR2RGB); im=Image.fromarray(rgb); im.thumbnail((500,400))
    photo=ImageTk.PhotoImage(im); preview.config(image=photo); preview.image=photo

app=tk.Tk(); app.title("Task 1 – Long Hair Analysis"); app.geometry("650x600")
tk.Label(app,text="Long Hair Identification – Safe Coursework Prototype",font=("Arial",16,"bold")).pack(pady=10)
tk.Button(app,text="Upload Image",command=choose).pack(pady=10)
preview=tk.Label(app); preview.pack()
label=tk.Label(app,text="Upload an image to analyse.",font=("Arial",12),justify="left"); label.pack(pady=15)
app.mainloop()

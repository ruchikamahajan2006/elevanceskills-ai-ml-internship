import tkinter as tk
from tkinter import filedialog, messagebox
import cv2, numpy as np, os, joblib
from PIL import Image, ImageTk

MODEL="sign_model.joblib"

def feature(img):
    img=cv2.resize(img,(64,64)); gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    gx=cv2.Sobel(gray,cv2.CV_32F,1,0,ksize=3); gy=cv2.Sobel(gray,cv2.CV_32F,0,1,ksize=3)
    mag=cv2.magnitude(gx,gy); mag=cv2.resize(mag,(32,32))
    return (mag/(mag.max()+1e-6)).ravel()

def predict(img):
    if not os.path.exists(MODEL):
        return "MODEL NOT TRAINED"
    model=joblib.load(MODEL)
    return str(model.predict([feature(img)])[0])

def upload():
    p=filedialog.askopenfilename(filetypes=[("Images","*.jpg *.jpeg *.png")])
    if not p:return
    img=cv2.imread(p)
    result=predict(img)
    rgb=cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
    im=Image.fromarray(rgb); im.thumbnail((500,380))
    ph=ImageTk.PhotoImage(im); preview.config(image=ph); preview.image=ph
    out.config(text="Prediction: "+result)

def webcam():
    cap=cv2.VideoCapture(0)
    while True:
        ok,frame=cap.read()
        if not ok: break
        pred=predict(frame)
        cv2.putText(frame,"Sign: "+pred+" | Q = quit",(10,30),0,.7,(0,255,0),2)
        cv2.imshow("Sign Language – Real Time",frame)
        if cv2.waitKey(1)&0xFF==ord("q"): break
    cap.release(); cv2.destroyAllWindows()

app=tk.Tk(); app.title("Task 4 – Sign Language Detection"); app.geometry("680x600")
tk.Label(app,text="Sign Language Recognition",font=("Arial",18,"bold")).pack(pady=12)
tk.Button(app,text="Upload Image",command=upload).pack(pady=5)
tk.Button(app,text="Real-Time Webcam",command=webcam).pack(pady=5)
preview=tk.Label(app); preview.pack(pady=12)
out=tk.Label(app,text="Train the model first, then upload an image.",font=("Arial",13)); out.pack(pady=10)
app.mainloop()

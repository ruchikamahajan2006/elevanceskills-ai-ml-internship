import os, cv2, numpy as np, joblib
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report

DATA="dataset"
MODEL="sign_model.joblib"

def feature(img):
    img=cv2.resize(img,(64,64))
    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    # Compact HOG-like gradient features using Sobel operators.
    gx=cv2.Sobel(gray,cv2.CV_32F,1,0,ksize=3)
    gy=cv2.Sobel(gray,cv2.CV_32F,0,1,ksize=3)
    mag=cv2.magnitude(gx,gy)
    mag=cv2.resize(mag,(32,32))
    return (mag/(mag.max()+1e-6)).ravel()

X=[]; y=[]
for label in sorted(os.listdir(DATA)):
    folder=os.path.join(DATA,label)
    if not os.path.isdir(folder): continue
    for fn in os.listdir(folder):
        img=cv2.imread(os.path.join(folder,fn))
        if img is not None:
            X.append(feature(img)); y.append(label)

if len(X)<20 or len(set(y))<2:
    raise SystemExit("Add at least 20 labelled images across at least 2 classes to task4_sign_language/dataset before training.")

X=np.asarray(X); y=np.asarray(y)
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.25,random_state=42,stratify=y)

model=make_pipeline(StandardScaler(),SVC(kernel="rbf",probability=True))
model.fit(Xtr,ytr)
pred=model.predict(Xte)
acc=accuracy_score(yte,pred)

print(f"Test accuracy: {acc:.3f}")
print(classification_report(yte,pred))
joblib.dump(model,MODEL)
print("Saved:",MODEL)

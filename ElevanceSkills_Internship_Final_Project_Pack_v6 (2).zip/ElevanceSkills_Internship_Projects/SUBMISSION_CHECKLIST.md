# Final Submission Checklist

- [ ] Install dependencies from requirements.txt
- [ ] Run each GUI successfully
- [ ] Capture at least 1 screenshot per task
- [ ] For Task 2, show visits.csv with generated entries
- [ ] For Task 4, add sample images under dataset/HELLO, YES, NO, THANK_YOU and run train.py
- [ ] Test image upload and webcam functions
- [ ] Add screenshots to the internship report
- [ ] Review every result and describe limitations honestly
- [ ] Do not claim an untrained baseline is a high-accuracy model
- [ ] Submit source code + report + evidence according to the portal instructions

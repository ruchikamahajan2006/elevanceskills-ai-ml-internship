import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk
import cv2, numpy as np

def dress_colour(img):
    h,w=img.shape[:2]
    roi=img[int(h*.45):int(h*.9),int(w*.25):int(w*.75)]
    hsv=cv2.cvtColor(roi,cv2.COLOR_BGR2HSV)
    H=np.mean(hsv[:,:,0]);S=np.mean(hsv[:,:,1]);V=np.mean(hsv[:,:,2])
    if S<40 and V>180:return "White/light"
    if V<65:return "Black/dark"
    if H<10 or H>170:return "Red"
    if H<35:return "Yellow/orange"
    if H<85:return "Green"
    if H<135:return "Blue"
    return "Other"

def emotion_proxy(face):
    gray=cv2.cvtColor(face,cv2.COLOR_BGR2GRAY)
    # Simple image-geometry proxy for demonstration, not a reliable emotion model.
    edges=cv2.Canny(gray,50,150).mean()
    return "Positive/neutral (demo)" if edges>18 else "Neutral (demo)"

def run():
    p=filedialog.askopenfilename(filetypes=[("Images","*.jpg *.jpeg *.png")])
    if not p:return
    img=cv2.imread(p);gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    faces=cv2.CascadeClassifier(cv2.data.haarcascades+"haarcascade_frontalface_default.xml").detectMultiScale(gray,1.1,5)
    if len(faces)==0: out.config(text="No face detected.");return
    x,y,w,h=faces[0]
    face=img[y:y+h,x:x+w]
    result=f"Age category: Estimated / uncertain\nDress colour: {dress_colour(img)}\nEmotion: {emotion_proxy(face)}\n\nNationality/ethnicity is not inferred from appearance."
    cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)
    rgb=cv2.cvtColor(img,cv2.COLOR_BGR2RGB);im=Image.fromarray(rgb);im.thumbnail((600,450))
    ph=ImageTk.PhotoImage(im);preview.config(image=ph);preview.image=ph;out.config(text=result)

app=tk.Tk();app.title("Task 6 – Visual Attribute Analysis");app.geometry("750x650")
tk.Label(app,text="Visual Attribute Analysis",font=("Arial",18,"bold")).pack(pady=12)
tk.Button(app,text="Upload Image",command=run).pack(pady=8)
preview=tk.Label(app);preview.pack()
out=tk.Label(app,text="Upload an image to analyse.",font=("Arial",12),justify="left");out.pack(pady=12)
app.mainloop()

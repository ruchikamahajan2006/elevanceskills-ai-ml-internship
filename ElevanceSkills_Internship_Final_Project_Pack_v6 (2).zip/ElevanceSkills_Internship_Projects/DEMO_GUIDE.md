# One-Day Demo Guide

## Task 1
Run `python task1_long_hair/app.py`. Upload a clear face image. Demonstrate face detection and hair-length visual estimate.

## Task 2
Run `python task2_senior_citizen/app.py`. Allow webcam access. Show multiple people if available. Press Q to exit. Open `visits.csv`.

## Task 3
Run `python task3_voice/app.py`. Use a short WAV/MP3/OGG recording. Demonstrate the GUI result.

## Task 4
Create four folders under `task4_sign_language/dataset`: HELLO, YES, NO, THANK_YOU. Add labelled sample images, run `train.py`, then run `app.py`.

## Task 5
Run `python task5_car_colour/app.py` and upload a traffic image.

## Task 6
Run `python task6_visual_attributes/app.py` and upload a portrait image.

## Evidence
For every task capture:
1. Input screen
2. Output screen
3. One sentence describing what worked

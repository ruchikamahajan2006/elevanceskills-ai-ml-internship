# Task 5 – Car Colour Detection

## Features
- GUI with image upload and preview
- Vehicle-like region detection
- Car colour estimation
- Car count
- Person count
- Blue cars shown with red rectangles
- Other colour cars shown with blue rectangles

## Note
The current implementation is a lightweight computer-vision prototype. Vehicle detection uses contour proposals rather than a separately trained object detector. This should be described accurately in the report.

## Run
`python app.py`

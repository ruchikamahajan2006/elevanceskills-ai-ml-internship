import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk
import cv2, numpy as np

# Traffic-image coursework prototype:
# Uses contour proposals for vehicle-like regions and colour statistics.
# For production, replace vehicle proposals with a trained object detector.

def car_colour(crop):
    hsv=cv2.cvtColor(crop,cv2.COLOR_BGR2HSV)
    h=np.mean(hsv[:,:,0]); s=np.mean(hsv[:,:,1]); v=np.mean(hsv[:,:,2])
    if s<45 and v<70: return "Black"
    if s<45 and v>180: return "White"
    if h<10 or h>170: return "Red"
    if 10<=h<35: return "Yellow/Orange"
    if 35<=h<85: return "Green"
    if 85<=h<135: return "Blue"
    return "Other"

def analyse():
    path=filedialog.askopenfilename(filetypes=[("Images","*.jpg *.jpeg *.png")])
    if not path:return

    img=cv2.imread(path)
    if img is None:return

    # Person detector
    hog=cv2.HOGDescriptor()
    hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
    people,_=hog.detectMultiScale(img,winStride=(8,8),padding=(8,8),scale=1.05)

    # Vehicle-like region proposals
    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    blur=cv2.GaussianBlur(gray,(5,5),0)
    edges=cv2.Canny(blur,70,150)
    contours,_=cv2.findContours(edges,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)

    vehicles=[]
    H,W=img.shape[:2]
    for c in contours:
        x,y,w,h=cv2.boundingRect(c)
        area=w*h
        if 0.0005*W*H < area < 0.35*W*H and w>55 and h>25 and w/h>1.15:
            vehicles.append((x,y,w,h))

    # Remove strongly overlapping boxes
    vehicles=sorted(vehicles,key=lambda b:b[2]*b[3],reverse=True)
    kept=[]
    for b in vehicles:
        x,y,w,h=b
        if all(abs(x-a)>0.35*min(w,aw) or abs(y-bb)>0.35*min(h,ah)
               for a,bb,aw,ah in kept):
            kept.append(b)
    vehicles=kept[:30]

    blue=0
    for x,y,w,h in vehicles:
        col=car_colour(img[y:y+h,x:x+w])
        # Requirement: red rectangle for blue cars; blue rectangle for other colours.
        rect=(0,0,255) if col=="Blue" else (255,0,0)  # BGR
        if col=="Blue": blue+=1
        cv2.rectangle(img,(x,y),(x+w,y+h),rect,2)
        cv2.putText(img,col,(x,y-6),cv2.FONT_HERSHEY_SIMPLEX,.5,rect,2)

    for x,y,w,h in people:
        cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)

    cv2.putText(img,f"Cars: {len(vehicles)} | People: {len(people)} | Blue cars: {blue}",
                (10,30),cv2.FONT_HERSHEY_SIMPLEX,.7,(0,255,255),2)

    rgb=cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
    im=Image.fromarray(rgb); im.thumbnail((760,480))
    ph=ImageTk.PhotoImage(im)
    preview.config(image=ph); preview.image=ph
    result.config(text=f"Cars detected: {len(vehicles)}\nPeople detected: {len(people)}\nBlue cars: {blue}")

app=tk.Tk()
app.title("Task 5 – Car Colour Detection")
app.geometry("850x680")

tk.Label(app,text="Car Colour + Traffic Counting",font=("Arial",18,"bold")).pack(pady=12)
tk.Label(app,text="Blue car → red rectangle | Other car colours → blue rectangle",
         font=("Arial",11)).pack()
tk.Button(app,text="Upload Traffic Image",command=analyse).pack(pady=10)
preview=tk.Label(app); preview.pack()
result=tk.Label(app,text="Upload a traffic image.",font=("Arial",12),justify="left")
result.pack(pady=12)

app.mainloop()

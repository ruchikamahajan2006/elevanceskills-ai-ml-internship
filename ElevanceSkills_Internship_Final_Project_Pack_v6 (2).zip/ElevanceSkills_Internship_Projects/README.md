# ElevanceSkills Internship – AI/ML Project Pack

This package contains six practical computer-vision/audio prototypes adapted for safe, demonstrable use.

## Projects
1. Long Hair / Age Category Analysis
2. Senior Citizen Identification + CSV Logging
3. Voice Age/Emotion Analysis
4. Sign Language Recognition (trainable gesture prototype)
5. Car Colour Detection + Vehicle/Person Counting
6. Visual Attribute Analysis (age category, dress colour, emotion)

## Installation
```bash
pip install -r requirements.txt
```

Run an individual GUI:
```bash
python task1_long_hair/app.py
python task2_senior_citizen/app.py
python task3_voice/app.py
python task4_sign_language/app.py
python task5_car_colour/app.py
python task6_visual_attributes/app.py
```

The applications are designed as coursework prototypes. Model-dependent tasks include training scripts/data folders where appropriate. Do not describe a heuristic as a trained deep-learning model in the report.

## Suggested demo
Use your own consented sample images/video/audio. For Task 2, the application writes detections to `task2_senior_citizen/visits.csv`.

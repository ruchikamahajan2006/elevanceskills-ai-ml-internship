# Final Submission Notes

## Important
This package contains coursework prototypes. Where a genuine trained model is required, the package includes a training workflow or clearly labels the result as an estimate/prototype.

## Task 4
1. Put labelled images in:
   - task4_sign_language/dataset/HELLO/
   - task4_sign_language/dataset/YES/
   - task4_sign_language/dataset/NO/
   - task4_sign_language/dataset/THANK_YOU/
2. Run `python task4_sign_language/train.py`.
3. Check the printed test accuracy.
4. Run `python task4_sign_language/app.py`.

For the strongest evidence, use at least 20–30 images per class with varied hand position/backgrounds and keep a separate test set if possible.

## Evidence
Take screenshots of training accuracy, GUI upload prediction, webcam prediction, and Task 2 CSV output.

## Ethics
Do not claim that the prototypes can reliably infer sensitive personal attributes such as nationality or gender from appearance/voice. Describe the implemented non-sensitive visual/audio features and limitations accurately.

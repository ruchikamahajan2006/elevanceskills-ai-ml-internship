import cv2, csv, os, time
from datetime import datetime

OUT="visits.csv"
if not os.path.exists(OUT):
    with open(OUT,"w",newline="",encoding="utf-8") as f:
        csv.writer(f).writerow(["time","person_id","age_estimate","senior_citizen"])

# Coursework prototype:
# Face detection is real-time; age estimation below is a transparent placeholder.
# Replace estimate_age() with a validated age model before claiming measured accuracy.

def estimate_age(face):
    # Deterministic demonstration rule so the application is runnable without
    # downloading a large external model.
    h,w=face.shape[:2]
    brightness=face.mean() if face.size else 0
    if h > w*1.30 and brightness < 115:
        return 65
    return 35

def log_visit(person_id, age):
    with open(OUT,"a",newline="",encoding="utf-8") as f:
        csv.writer(f).writerow([
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            person_id, age, "Yes" if age>60 else "No"
        ])

cap=cv2.VideoCapture(0)
cascade=cv2.CascadeClassifier(cv2.data.haarcascades+"haarcascade_frontalface_default.xml")

last_logged={}
frame_no=0

while True:
    ok,frame=cap.read()
    if not ok:
        print("Could not access webcam.")
        break

    gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    faces=cascade.detectMultiScale(gray,scaleFactor=1.1,minNeighbors=5,minSize=(60,60))

    for person_id,(x,y,w,h) in enumerate(faces,1):
        face=frame[y:y+h,x:x+w]
        age=estimate_age(face)
        senior=age>60

        # Green for senior, blue for non-senior.
        color=(0,255,0) if senior else (255,150,0)
        cv2.rectangle(frame,(x,y),(x+w,y+h),color,2)
        cv2.putText(frame,f"Person {person_id} | Age: {age}",
                    (x,y-28),cv2.FONT_HERSHEY_SIMPLEX,.55,color,2)
        cv2.putText(frame,"Senior Citizen" if senior else "Non-senior",
                    (x,y-8),cv2.FONT_HERSHEY_SIMPLEX,.55,color,2)

        # Log each detected track slot at most once every 10 seconds.
        now=time.time()
        if person_id not in last_logged or now-last_logged[person_id]>=10:
            log_visit(person_id,age)
            last_logged[person_id]=now

    cv2.putText(frame,f"People: {len(faces)} | CSV: visits.csv",
                (10,30),cv2.FONT_HERSHEY_SIMPLEX,.65,(0,255,255),2)
    cv2.putText(frame,"Press Q to quit",(10,55),cv2.FONT_HERSHEY_SIMPLEX,.55,(255,255,255),2)

    cv2.imshow("Task 2 – Senior Citizen Identification",frame)
    key=cv2.waitKey(1)&0xFF
    if key==ord("q"): break

cap.release()
cv2.destroyAllWindows()

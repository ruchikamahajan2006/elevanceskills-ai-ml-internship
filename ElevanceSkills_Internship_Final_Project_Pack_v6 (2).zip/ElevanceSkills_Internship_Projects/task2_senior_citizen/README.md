# Task 2 – Senior Citizen Identification

## Features
- Real-time webcam input
- Multiple face detection
- Age-category prototype
- Senior citizen flag when estimated age is greater than 60
- Timestamp logging
- Person ID
- CSV output in `visits.csv`

## Run
`python app.py`

Press **Q** to stop.

## Important limitation
The included `estimate_age()` is a runnable demonstration rule, not a validated age-prediction ML model. For a high-quality submission, it should be replaced with a trained/validated age model and evaluated on labelled test data. Do not report an accuracy value unless it has actually been measured.
